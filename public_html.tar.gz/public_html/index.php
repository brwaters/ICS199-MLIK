<!doctype html>
<html>
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="./css.css">
<title>home</title>
			<?php $page = "index"; include 'navbar.php'; ?>
</head>

<body>
<div>
<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec vel blandit nisi. Ut vitae orci ornare, varius turpis tristique, posuere magna. Nullam aliquet augue sapien, id mollis odio dictum id. Nullam pulvinar tristique eros, ac dapibus ipsum auctor eu. Praesent dapibus posuere commodo. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec scelerisque congue nibh et rhoncus. Nam dapibus nisl quis sollicitudin semper. Morbi in elit luctus, ullamcorper nisi in, imperdiet urna. Etiam justo urna, aliquet nec lobortis quis, scelerisque vitae libero. Curabitur ipsum nisl, tincidunt vel justo at, vulputate sodales elit. Nulla nec dui non risus lacinia tincidunt. Maecenas orci purus, rutrum at libero at, consectetur venenatis nunc. Donec elementum enim vel sapien venenatis, eu tristique mi volutpat. </p>
<p> Aliquam euismod justo nec justo imperdiet, ut maximus nisi porta. Donec diam est, convallis at iaculis eu, viverra non enim. In consequat accumsan sapien et convallis. Etiam ac porttitor diam, vel mollis odio. Fusce sed leo efficitur, sagittis mi in, laoreet justo. Curabitur auctor lacus ac urna venenatis posuere. Aliquam erat volutpat. Maecenas volutpat ligula quis lacus feugiat, sit amet vehicula enim varius. Donec congue eget metus ut fringilla. Proin leo libero, lacinia sed augue aliquam, auctor placerat justo. </p>
<p> Aenean et mi velit. Suspendisse blandit id enim nec feugiat. Vivamus leo massa, lobortis eget ante nec, dapibus luctus lectus. Aenean non urna quis urna vehicula tincidunt ac at quam. Nam consequat metus quis velit commodo, ut consequat tellus pulvinar. Quisque ullamcorper, neque eu varius aliquam, justo tellus rhoncus lectus, eu porttitor purus ante nec nisl. Sed tempor quam id velit cursus ultricies. Integer in nisl id nulla maximus malesuada. Morbi ornare vulputate sem, id lobortis nulla accumsan eget. Quisque aliquet maximus urna. In egestas sem quis magna vulputate, eu maximus quam convallis. </p>
<p> Vestibulum dapibus, diam eu consectetur auctor, neque sapien iaculis odio, sed porttitor neque diam et est. Morbi eu ante vel lectus gravida sollicitudin. Etiam faucibus mollis scelerisque. Morbi dapibus nibh sed purus ornare congue. Sed maximus, nisi vel tristique blandit, lacus libero mollis justo, pulvinar commodo eros lorem eu dui. Nunc lacinia luctus sodales. Integer ac mattis mi. Curabitur egestas justo nec risus pretium aliquet. Nunc ac nibh non augue ultricies congue. Vivamus faucibus, odio sit amet bibendum fermentum, ex elit venenatis arcu, quis imperdiet nisl quam ut neque. Aenean enim nisi, elementum a sem eu, vestibulum pellentesque lacus. Aenean eget libero felis. Aenean at facilisis mi, eu fringilla nibh. </p>
	</div>
</body>
<footer>
  <hr>
  We sell quality goods! Check us out on Twitter, Social Media Site 1, Social Media Site 2</footer>
</html>
