<!doctype html>
<html>
	<head>
		<meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" href="./css.css">
		<title>About Us - MLIK</title>
			<?php $page = "about"; include 'navbar.php'; ?>
</head>

<body>
	<div>
		<p>This is our group's project about page, informing our lovely customers about who we are and what we sell.</p>
	</div>
</body>
<?php include 'footer.php';?>
</html>
