<?php
$nav = "<div id=\"footer\">
    <footer>
	  <hr>
	  We sell quality goods! Check us out on Twitter, Social Media Site 1, Social Media Site 2
	</footer>
        </div>";
echo $nav;
?>
